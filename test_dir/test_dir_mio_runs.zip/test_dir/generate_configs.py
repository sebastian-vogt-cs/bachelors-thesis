#!/usr/bin/python3
import glob
import os
import wsgiref.validate

CONFIG_DIR = os.path.join(os.getcwd(), "configs")
APP_FOLDER_NAME = "bachelor-thesis-apps/apps"

# All the properties that are the same for all apps in the mate.properties for
# block coverage
props_blocks = {
    'timeout': '1440',
    'coverage': 'BRANCH_COVERAGE',
    'max_number_events': '50',
    'record_test_case': 'true',
    'population_size': '10',
    'big_population_size': '1',
    'algorithm': 'MIO',
    'fitness_function': 'BRANCH_MULTI_OBJECTIVE',
    'mutation_function': 'TEST_CASE_CUT_POINT_MUTATION',
    'termination_condition': 'ITERATION_TERMINATION',
    'evo_iterations_number': '200',
    'chromosome_factory': 'ANDROID_RANDOM_CHROMOSOME_FACTORY',
    'p_mutate': '1',
    'p_crossover': '0',
    'objective': 'BRANCHES',
    'p_sample_random': '0.5',
    'p_focused_search_start': '0.5',
    'mutation_rate': '1'
}
# mate.properties for branch coverage
props_branches = {
    'timeout': '1440',
    'coverage': 'BRANCH_COVERAGE',
    'max_number_events': '50',
    'record_test_case': 'true',
    'population_size': '10',
    'big_population_size': '1',
    'algorithm': 'MIO',
    'fitness_function': 'BRANCH_DISTANCE_MULTI_OBJECTIVE',
    'mutation_function': 'TEST_CASE_CUT_POINT_MUTATION',
    'termination_condition': 'ITERATION_TERMINATION',
    'evo_iterations_number': '200',
    'chromosome_factory': 'ANDROID_RANDOM_CHROMOSOME_FACTORY',
    'p_mutate': '1',
    'p_crossover': '0',
    'objective': 'BRANCHES',
    'p_sample_random': '0.5',
    'p_focused_search_start': '0.5',
    'mutation_rate': '1',
    'graph_type': 'INTER_CFG',
    'target': 'no_target',
    'draw_raw_graph': 'false'
}


# All the properties that are the same for all apps in the config.ini for block
# coverage
ini_blocks = {
    '[MATE]': {
        'test': 'ExecuteMATEMIO'
    },
    '[COMMANDER]': {
        'apps_dir': APP_FOLDER_NAME
    }
}
# config.ini for branch coverage
ini_branches = {
    '[MATE]': {
        'test': 'ExecuteMATEMIO'
    },
    '[COMMANDER]': {
        'apps_dir': APP_FOLDER_NAME
    }
}

# Contents of the general config.ini file
config_ini = {
    '[EMULATOR]': {
        'install_dependencies': 'yes',
        'use_emulator': 'yes',
        'device_id': 'testAVD',
        'headless': 'yes',
        'log': 'yes',
        'logfile': 'log/emu.log',
        'logfile_err': 'log/emu_err.log',
        'logcat_tags': 'E,acc'
    },
    '[MATE_SERVER]': {
        'jar': 'yes',
        'command': 'bin/mate-server.jar',
        'log': 'yes',
        'logfile': 'log/server.log',
        'logfile_err': 'log/server_err.log'
    },
    '[MATE]': {
        'wait_for_app': '10'
    }
}

server_blocks = {
    'apps_dir': APP_FOLDER_NAME,
    'port': '0'
}

server_branches = {
    'apps_dir': APP_FOLDER_NAME,
    'port': '0'
}

remainingWdhsDistance = {
    'com.oriondev.moneywallet': 0,
    'org.quantumbadger.redreader': 0,
    'net.gsantner.markor': 0,
    'de.retujo.bierverkostung': 0,
    'de.rampro.activitydiary': 0,
    'de.arnowelzel.android.periodical': 1,
    'protect.rentalcalc': 1,
    'de.drhoffmannsoftware': 1,
    'com.woefe.shoppinglist': 0
}

remainingWdhsNoDistance = {
    'com.oriondev.moneywallet': 0,
    'org.quantumbadger.redreader': 0,
    'net.gsantner.markor': 0,
    'de.retujo.bierverkostung': 0,
    'de.rampro.activitydiary': 0,
    'de.arnowelzel.android.periodical': 1,
    'protect.rentalcalc': 1,
    'de.drhoffmannsoftware': 1,
    'com.woefe.shoppinglist': 0 
}

def add_app_id(app_name):
    ini_branches['[APP]'] = {'id': app_name}
    ini_blocks['[APP]'] = {'id': app_name}


def add_apk_for_graph(path):
    props_branches['apk'] = path


def add_guidance_level(level):
    props_blocks['guidance_level'] = level


guidance_levels = ['1']


def gen_configs():
    counter = 0
    config_ini_file = os.path.join(CONFIG_DIR, "config.ini")
    with open(config_ini_file, "w+") as file:
        for key, value in config_ini.items():
            file.write(key + '\n')
            for k, v in value.items():
                file.write(k + "=" + v + '\n')

    for apk in glob.glob(APP_FOLDER_NAME + "/*.apk"):
        app_name = apk.split(".apk")[0].split(os.sep)[2]
        numWdh = remainingWdhsNoDistance[app_name]
        for wdh in range(0, numWdh):
            for level in guidance_levels:
                config_file = os.path.join(CONFIG_DIR, str(counter))
                add_app_id(app_name)
                with open(config_file, "w+") as file:
                    for key, value in ini_blocks.items():
                        file.write(key + '\n')
                        for k, v in value.items():
                            file.write(k + "=" + v + '\n')
                # add_apk_for_graph(os.getcwd() + os.sep + app_name + os.sep + app_name + "-original.apk")
                prop_file = str(counter) + ".prop"
                prop_file = os.path.join(CONFIG_DIR, prop_file)
                add_guidance_level(level)
                server_file = str(counter) + ".server"
                server_file = os.path.join(CONFIG_DIR, server_file)
                with open(prop_file, "w+") as file:
                    for key, value in props_blocks.items():
                        file.write(key + "=" + value + '\n')
                with open(server_file, "w+") as file:
                    for key, value in server_blocks.items():
                        file.write(key + "=" + value + '\n')
                counter += 1
    
    for apk in glob.glob(APP_FOLDER_NAME + "/*.apk"):
        app_name = apk.split(".apk")[0].split(os.sep)[2]
        numWdh = remainingWdhsDistance[app_name]
        for wdh in range(0, numWdh):
            config_file = os.path.join(CONFIG_DIR, str(counter))
            add_app_id(app_name)
            with open(config_file, "w+") as file:
                for key, value in ini_branches.items():
                    file.write(key + '\n')
                    for k, v in value.items():
                        file.write(k + "=" + v + '\n')
            add_apk_for_graph(os.getcwd() + os.sep + APP_FOLDER_NAME + os.sep + app_name + os.sep + app_name + "-original.apk")
            prop_file = str(counter) + ".prop"
            prop_file = os.path.join(CONFIG_DIR, prop_file)
            #add_guidance_level(level)
            server_file = str(counter) + ".server"
            server_file = os.path.join(CONFIG_DIR, server_file)
            with open(prop_file, "w+") as file:
                for key, value in props_branches.items():
                    file.write(key + "=" + value + '\n')
            with open(server_file, "w+") as file:
                for key, value in server_branches.items():
                    file.write(key + "=" + value + '\n')
            counter += 1




if __name__ == "__main__":
    gen_configs()

