#!/bin/bash

rm log/*
./clear-testcases.sh
./clear-traces.sh

rm -rf results

rm -rf apps/*/coverage/

