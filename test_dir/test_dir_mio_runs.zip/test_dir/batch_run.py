#!/usr/bin/python3

import subprocess
import getpass
from os import listdir, getcwd
from os.path import isfile, join

username = getpass.getuser()

def isInt(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

config_dir = join(getcwd(), "configs")
listOfFiles = [f for f in listdir(config_dir) if isfile(join(config_dir, f)) and isInt(f)]
c = str(max(map(int, listOfFiles)))

constraint="--constraint=pontipine"
exclude="--exclude=pontipine01"
test_dir = getcwd()
subprocess.run(["sbatch", constraint, exclude, "--exclusive", "--signal=B:TERM@180",
    "--time=1440", "--mem=250000", "--job-name=RNDwalk",  \
"-c 10", "-a 0-" + c, "--output", f"/scratch/{username}/sbatch_out/slurm-%A_%a.out", f"--export=ALL,TEST_DIR={test_dir}", \
f"/scratch/{username}/home/mate-commander/start_run.py"])
