#!/bin/bash

for file in apps/*; do
	if [[ -d $file ]]; then
		if [[ -d $file/test-cases ]]; then
			# echo "$file/test-cases"
			rm -rf $file/test-cases/*
		fi
	fi
done

