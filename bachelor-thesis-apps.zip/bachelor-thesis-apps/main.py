import os
from random import randrange
from os import listdir
from os.path import isfile, join

PATH_TO_APPS_FOLDER = "apps"

USED_TXT_FILE = "branches.txt"

BACKUP_TXT_FILE = USED_TXT_FILE + "-backup.txt"

NUMBER_OF_SAMPLES = 10000


def sample(objectives: list, n: int):
    sampled_objectives = []
    active_objectives = list(range(0, len(objectives)))
    active_length = len(objectives)
    while len(sampled_objectives) < n and active_length > 0:
        rand = randrange(0, active_length, 1)
        sampled_objectives.append(objectives[active_objectives[rand]])
        active_objectives[rand] = active_objectives[active_length - 1]
        active_length -= 1
    return sampled_objectives


if __name__ == '__main__':
    #
    # lines = []
    #
    # with open("branches.txt") as file:
    #     for line in file:
    #         lines.append(line)
    #
    # with open("branches_new.txt", "+w") as file:
    #     for line in sample(lines, 15):
    #         file.write(line)
    folders = [join(PATH_TO_APPS_FOLDER, folder) for folder in listdir(PATH_TO_APPS_FOLDER) if
               not isfile(join(PATH_TO_APPS_FOLDER, folder))
               and not folder == ".git"
               and not folder == ".idea"]
    for folder in folders:
        used_txt_path = join(folder, USED_TXT_FILE)
        backup_txt_path = join(folder, BACKUP_TXT_FILE)

        if not os.path.exists(backup_txt_path):
            os.rename(used_txt_path, backup_txt_path)

        lines = []
        with open(backup_txt_path) as file:
            for line in file:
                lines.append(line)

        print(folder + ": had " + str(len(lines)) + " objectives before sampling to " + str(NUMBER_OF_SAMPLES))

        with open(used_txt_path, "+w") as file:
            sampledObjectives = sample(lines, NUMBER_OF_SAMPLES)
            print(folder + ": now has " + str(len(sampledObjectives)) + " objectives")
            for line in sampledObjectives:
                file.write(line)
